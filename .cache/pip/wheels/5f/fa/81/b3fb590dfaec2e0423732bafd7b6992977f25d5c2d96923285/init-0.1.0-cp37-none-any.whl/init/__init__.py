# coding: utf-8
# flake8: noqa

from . import info
from terminal.prompt import *

__version__ = info.VERSION
