# coding: utf-8

NAME = 'init'

VERSION = '0.1.0'

AUTHOR = 'Hsiaoming Yang <me@lepture.com>'

REPOSITORY = 'https://github.com/lepture/init'

ISSUE_TRACKER = 'https://github.com/lepture/init/issues'

LICENSE = 'BSD 3'
